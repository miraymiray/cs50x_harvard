-- print the average energy of songs 
SELECT AVG(energy) FROM songs;