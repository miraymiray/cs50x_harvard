-- print ordered version of songs by tempo
SELECT name FROM songs ORDER BY tempo;