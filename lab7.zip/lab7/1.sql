-- print all of the songs
SELECT name FROM songs;