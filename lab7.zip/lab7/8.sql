-- print the featuring songs
SELECT name FROM songs WHERE name LIKE '%feat.%';